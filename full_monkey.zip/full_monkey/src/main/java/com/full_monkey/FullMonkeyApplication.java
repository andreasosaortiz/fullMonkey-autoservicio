package com.full_monkey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullMonkeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullMonkeyApplication.class, args);
	}

}
