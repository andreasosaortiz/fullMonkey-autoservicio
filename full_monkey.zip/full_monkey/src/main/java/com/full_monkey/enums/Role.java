package com.full_monkey.enums;


public enum Role {

    ADMIN, USER;
}

