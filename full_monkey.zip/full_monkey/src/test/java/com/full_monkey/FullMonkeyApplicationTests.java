package com.full_monkey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullMonkeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
